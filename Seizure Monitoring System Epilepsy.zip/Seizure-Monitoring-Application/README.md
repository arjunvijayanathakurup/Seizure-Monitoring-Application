# Seizure-Monitoring-Application
Seizure monitoring system for epileptic patients
